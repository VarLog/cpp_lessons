Test cool game project

