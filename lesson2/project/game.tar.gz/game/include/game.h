#ifndef GAME_H
#define GAME_H

class Game {
    public:
        int run();
};

#endif  // GAME_H
