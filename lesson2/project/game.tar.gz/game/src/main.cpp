#include <iostream>

#include "game.h"

int main()
{
    std::cout << "Hello game" << std::endl;

    Game game;

    auto res = game.run();

    return res;
}
