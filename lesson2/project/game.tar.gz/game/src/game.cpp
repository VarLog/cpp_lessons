#include "game.h"

#include <iostream>
#include <random>

int Game::run()
{
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(1, 9);

    auto score = 0;

    auto answer = 0;

    while(std::cin.good())
    {
        auto a = dis(gen);
        auto b = dis(gen);

        std::cout << a << " + " << b << std::endl;

        std::cin >> answer;

        if(answer == a+b)
        {
            ++score;

            std::cout << "Correct!" << std::endl;
            std::cout << "Your score: " << score << std::endl;
        }
        else
        {
            std::cout << "Mistake!" << std::endl;
        }
    }

    return 0;
}

